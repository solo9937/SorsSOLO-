# SOLO Factory - Repo Template

## What this repo contains
- `main.py` : launcher that runs a small Flask server and the Pyrogram bot client.
- `server.py` : optional standalone Flask server.
- `runtime_config.py` : runtime config manager for OWNER and SUDO_USERS.
- `admin_commands.py` : helper functions for owner/sudo commands.
- `requirements.txt`, `Procfile` : for deployment (Render/Koyeb).
- `config_runtime.json` : default runtime config (created automatically if missing).

## How to use
1. Add your bot code (handlers, factory logic) into this repo. Do NOT commit secrets.
2. Add your secrets in Render/Koyeb/GitHub Secrets environment variables:
   - `BOT_TOKEN`
   - `API_ID`
   - `API_HASH`
   - Optionally `OWNER_ID`, `SUDO_USERS`
3. Deploy on Render/Koyeb using GitHub integration or upload the repo.

## Deploy notes
- `Procfile` defines `web: python main.py` for platforms that expect a web process.
- `main.py` starts a web server and the bot so the container/service stays alive.
- Keep token secret; use environment variables or secret store.
