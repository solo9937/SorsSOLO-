# main.py
# Launcher: runs a small Flask web server (for uptime pings) and a Pyrogram bot client.
import os
import threading
from flask import Flask
from pyrogram import Client

# Read environment variables (do NOT hardcode tokens here)
BOT_TOKEN = os.environ.get("BOT_TOKEN")
API_ID = os.environ.get("API_ID")
API_HASH = os.environ.get("API_HASH")

if not BOT_TOKEN or not API_ID or not API_HASH:
    raise SystemExit("Missing BOT_TOKEN, API_ID or API_HASH environment variables.")

API_ID = int(API_ID)

# Create Pyrogram client (session name uses 'solo' so session file will be created)
app_bot = Client(
    "solo_session",
    api_id=API_ID,
    api_hash=API_HASH,
    bot_token=BOT_TOKEN,
    workdir="."  # keep session files in repo root
)

# Simple Flask server for uptime checking
server = Flask(__name__)

@server.route("/")
def home():
    return "SOLO Factory is running!"

def run_server():
    # Render/Koyeb/Render expect the app to listen on port 10000 or $PORT (use PORT env when present)
    port = int(os.environ.get("PORT", "10000"))
    server.run(host="0.0.0.0", port=port)

def run_bot():
    print("Starting Pyrogram bot...")
    app_bot.run()

if __name__ == "__main__":
    # Start Flask in a thread so the bot and webserver run together
    t = threading.Thread(target=run_server, daemon=True)
    t.start()
    run_bot()
